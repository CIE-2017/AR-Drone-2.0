from django.db import models

#class Pic(models.Model):
    #date = models.DateTimeField()
    # pic mightbe = ImageFild
    

# Create your models here.
