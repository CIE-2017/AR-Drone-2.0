from django.shortcuts import render
from django.http import HttpResponse

def indexx(request):
    return HttpResponse("<h2>it worked</h2>")
# Create your views here.
