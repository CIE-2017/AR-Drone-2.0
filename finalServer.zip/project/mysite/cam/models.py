from django.db import models

class DroneInfo(models.Model):
    pic = models.ImageField()
    gps = models.CharField(max_length=500)
    date = models.DateTimeField(auto_now_add=True, blank=True)
    boo = models.BooleanField()
class DroneInfo2(models.Model):
    pic = models.ImageField()
    gps = models.CharField(max_length=500)
    date = models.DateTimeField()
    tem = models.IntegerField()



class pic(models.Model):
    pic = models.ImageField()
class gps(models.Model) :
    date = models.DateTimeField(auto_now_add=True, blank=True)
    tem = models.FloatField()
    gps = models.CharField(max_length=500)
    
    
    

# Create your models here.
