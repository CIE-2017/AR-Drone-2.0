from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$',views.stream, name='stream'),
    url(r'^upload$',views.upload, name='upload'),
    url(r'^pic$',views.pic, name='pic')
    ]

