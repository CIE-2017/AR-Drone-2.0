from django.http import HttpResponse
from django.shortcuts import render, render_to_response
from .models import DroneInfo2, gps, pic
from .form import UploadPicForm, UploadGpsForm
from django.views.decorators.csrf import csrf_exempt
from django.core.files import File
from random import randint
import binascii
import urllib
from datetime import datetime


def stream (request):
    all_picture =  gps.objects.all()
    dic = {'all_picture' : all_picture}
    #print(dic)
    return render(request,'cam/picture.html',dic)
    #return HttpResponse("<h2>123</h2>")

def pic (request):
    all_picture =  pic.objects.all()
    dic = {'all_picture' : all_picture}

    return render(request,'cam/pic.html',dic)

@csrf_exempt
def upload(request):
    if request.method == 'POST':
        print("start up load")
        form = UploadPicForm(request.POST)
        if form.is_valid():
            print("form pic is valid")
            hex2pic = request.POST.get('pic')
            #gps=request.POST.get('gps')
            print(hex2pic)
            #print(gps)
            date = str(datetime.now().date())
            time = str(datetime.now().time())
            hr = time[:2]
            mi = time[3:5]
            se = time[6:8]
            dtString = date+'_'+hr+'-'+mi+'-'+se

            #convert hex
            nf = open(r"C:/Users/User/Desktop/project/mysite/media/pic_%s.jpg" %(dtString),"wb")
            d = hex2pic.strip()
            nf.write(binascii.a2b_hex(d))
            #
            nf.close()
            
            img = File(open(r"C:/Users/User/Desktop/project/mysite/media/pic_%s.jpg" %(dtString),"rb"))
            #save
            instance = pic(pic=img)
            instance.save()
            img.close()
            return stream (request)
        else:
            form = UploadGpsForm(request.POST)
            if form.is_valid():
                print("form gps is valid")
                tem=request.POST.get('tem')      
                tems = float(tem)
                
                instance = gps(tem=tems,gps=request.POST.get('gps'))
                instance.save()
                return stream (request)
                
        return HttpResponse("<h2>form is not vaild</h2>")
    else:
        return HttpResponse("<h2>method is not post</h2>")



"""f = open ("hex2pic.txt","r")
nf = open("binaryData14.jpg","wb")
s
#Read whole file into data
while 1:
    c = f.readline()
    d = c.strip()
    if not c:
        break
    nf.write(binascii.a2b_hex(bytes(d)))


# Close the file
f.close()
nf.close()"""

