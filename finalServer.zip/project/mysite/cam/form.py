from django import forms

class UploadPicForm(forms.Form):
    pic = forms.CharField(widget=forms.Textarea)


class UploadGpsForm(forms.Form):
    gps = forms.CharField()
    tem = forms.CharField(widget=forms.Textarea)
    
