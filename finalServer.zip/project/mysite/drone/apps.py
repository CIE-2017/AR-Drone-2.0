from django.apps import AppConfig


class DroneConfig(AppConfig):
    name = 'drone'
