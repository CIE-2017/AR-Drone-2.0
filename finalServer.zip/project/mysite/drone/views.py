from django.shortcuts import render

def index(request):
    return render(request, 'drone/home.html')

# Create your views here.
